package org.example.bot_talimnew.user;

public class User {
    private Long chatId;
    private
}
