package org.example.bot_talimnew;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BotTalimNewApplication {

    public static void main(String[] args) {
        SpringApplication.run(BotTalimNewApplication.class, args);
    }

}
